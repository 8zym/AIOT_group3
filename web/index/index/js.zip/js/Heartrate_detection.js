// heartRateChart.js

var myChart = echarts.init(document.getElementById('heartRateChart'));

var heart_rate_data = [];
var time_data = [];
var max_data_points = 60;  // 假设显示最近60个数据点

function updateHeartRateChart() {
    myChart.setOption({
        backgroundColor: 'rgba(1,202,217,.2)',
        grid: {
            left: 60,
            right: 50,
            top: 100,
            bottom: 50
        },
        title: {
            text: '实时心率监测',
            top: 20,
            left: 'center',
            textStyle: {
                fontSize: 18,
                color: '#ffffff'
            }
        },
        xAxis: {
            name: '时间',
            type: 'category',
            axisLine: {
                lineStyle: {
                    color: 'rgba(255,255,255,.2)'
                }
            },
            splitLine: {
                lineStyle: {
                    color: 'rgba(255,255,255,.1)'
                }
            },
            axisLabel: {
                color: "rgba(255,255,255,.7)"
            },
            data: time_data,
            axisPointer: {
                type: 'shadow'
            }
        },
        yAxis: {
            type: 'value',
            name: '心率',
            axisLine: {
                lineStyle: {
                    color: 'rgba(255,255,255,.3)'
                }
            },
            splitLine: {
                lineStyle: {
                    color: 'rgba(255,255,255,.1)'
                }
            },
            axisLabel: {
                color: "rgba(255,255,255,.7)"
            },
            min: 50,
            max: 120
        },
        series: [{
            name: '心率',
            type: 'line',
            data: heart_rate_data,
            smooth: true,
            itemStyle: {
                color: '#ff7f50',
                opacity: 0.8,
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)',
            },
            lineStyle: {
                width: 2
            }
        }]
    });
}

var socket = new WebSocket('ws://localhost:6789');

socket.onmessage = function(event) {
    var data = JSON.parse(event.data);
    console.log("Received data:", data);
    var heart_rate = parseInt(data.heart_rate, 10); // 确保心率数据为数字
    var currentTime = new Date().toLocaleTimeString();

    if (heart_rate_data.length >= max_data_points) {
        heart_rate_data.shift();
        time_data.shift();
    }

    heart_rate_data.push(heart_rate);
    time_data.push(currentTime);

    console.log("Updated heart_rate_data:", heart_rate_data);
    console.log("Updated time_data:", time_data);

    updateHeartRateChart();
};

// 初始化图表
updateHeartRateChart();