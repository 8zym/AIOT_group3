var Chartone = echarts.init(document.getElementById('averageStatisticsChart'));
// 生成模拟数据
var fatigue_data = [];
for (var i = 0; i < 3; i++) {  // 三个类别：温度、湿度、光照强度
    var _data = [];
    for (var j = 0; j < 30; j++) {
        if (i === 0) { // 温度
            _data.push(20 + randomNum(15, 25));   // 模拟温度数据
        }
        if (i === 1) { // 湿度
            _data.push(50 + randomNum(30, 70));   // 模拟湿度数据
        }
        if (i === 2) { // 光照强度
            _data.push(500 + randomNum(400, 1600)); // 模拟光照强度数据
        }
    }
    fatigue_data.push(_data);
}

var option = {
    backgroundColor: 'rgba(1,202,217,.2)',
    grid: {
        left: 60,
        right: 50,
        top: 100,
        bottom: 50
    },
    title: {
        text: '近三十天驾驶环境平均数据统计',
        top: 20,
        left: 'center',
        textStyle: {
            fontSize: 18,
            color: '#ffffff'
        }
    },
    legend: {
        top: 50,
        left: 'center',
        textStyle: {
            fontSize: 12,
            color: 'rgba(255,255,255,.7)'
        },
        data: ['温度', '湿度', '光照强度']
    },
    xAxis: {
        name: '日期',
        type: 'category',
        axisLine: {
            lineStyle: {
                color: 'rgba(255,255,255,.2)'
            }
        },
        splitLine: {
            lineStyle: {
                color: 'rgba(255,255,255,.1)'
            }
        },
        axisLabel: {
            color: "rgba(255,255,255,.7)"
        },
        data: ['6-01', '6-02', '6-03', '6-04', '6-05', '6-06', '6-07', '6-08', '6-09', '6-10',
            '6-11', '6-12', '6-13', '6-14', '6-15', '6-16', '6-17', '6-18', '6-19', '6-20',
            '6-21', '6-22', '6-23', '6-24', '6-25', '6-26', '6-27', '6-28', '6-29', '6-30'
        ],
        axisPointer: {
            type: 'shadow'
        }
    },
    yAxis: {
        type: 'value',
        name: '数值',
        axisLine: {
            lineStyle: {
                color: 'rgba(255,255,255,.3)'
            }
        },
        splitLine: {
            lineStyle: {
                color: 'rgba(255,255,255,.1)'
            }
        },
        axisLabel: {
            color: "rgba(255,255,255,.7)"
        },
        nameTextStyle: {
            color: "rgba(255,255,255,.7)"
        }
    },
    series: [{
            name: '温度',
            type: 'line',
            data: fatigue_data[0],
            smooth: true,
            itemStyle: {
                color: '#ff7f50',
                opacity: 0.8,
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)',
            },
            lineStyle: {
                width: 2
            }
        }, {
            name: '湿度',
            type: 'line',
            data: fatigue_data[1],
            smooth: true,
            itemStyle: {
                color: '#87cefa',
                opacity: 0.8,
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)',
            },
            lineStyle: {
                width: 2
            }
        }, {
            name: '光照强度',
            type: 'line',
            data: fatigue_data[2],
            smooth: true,
            itemStyle: {
                color: '#da70d6',
                opacity: 0.8,
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)',
            },
            lineStyle: {
                width: 2
            }
        }
    ]
};

Chartone.setOption(option);

// 随机数生成函数
function randomNum(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
