import asyncio
import websockets
import json
import pymysql

async def send_heart_rate(websocket, path):
    db = pymysql.connect(
        host='47.121.193.122',
        user='root',
        password='123456',
        database='emqx_data',
        cursorclass=pymysql.cursors.DictCursor
    )
    cursor = db.cursor()
    
    try:
        while True:
            query = 'SELECT * FROM heart_rate ORDER BY id DESC LIMIT 30;'  # 获取最新30条心率数据
            cursor.execute(query)
            results = cursor.fetchall()
            heart_rates = [row['heart_rate'] for row in results]
            await websocket.send(json.dumps(heart_rates))
            await asyncio.sleep(15)
    except websockets.exceptions.ConnectionClosed as e:
        print(f"Connection closed: {e}")
    finally:
        cursor.close()
        db.close()

async def main():
    async with websockets.serve(send_heart_rate, "localhost", 6789):
        print("WebSocket server started")
        await asyncio.Future()  # run forever

asyncio.run(main())

